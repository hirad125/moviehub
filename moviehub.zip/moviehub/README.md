# MovieHub

پنل خصوصی فیلم - نسخه اولیه

## راه‌اندازی

1. این ریپو را به GitHub پوش کنید
2. در Vercel پروژه را Import کنید
3. در بخش Environment Variables این دو متغیر را اضافه کنید:

```
NEXT_PUBLIC_SUPABASE_URL=https://iqtxtshxnbhmlodydmkm.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_dMtwln_U73KQ223bd0JeVA_k5kI_1Vs
```

4. Deploy کنید

## ساختار فعلی

- صفحه اصلی با ۴ کارت (مطابق طراحی)
- سیستم انتخاب نیم نمایشی
- اتصال اولیه به Supabase
